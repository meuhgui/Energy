package energy.view;

public interface Observer {
    void update(Observable observed);
}